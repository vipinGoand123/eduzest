<?php
session_start();
include_once('config.php');

$sessid = $_SESSION['sess_id'];

if (!empty(isset($_POST['logout']))) {



    $update = "UPDATE `activity` SET `signout_time`= Now() WHERE `session_id` = '$sessid'";
    mysqli_query($conn, $update);


    unset($_SESSION['user']);
}
