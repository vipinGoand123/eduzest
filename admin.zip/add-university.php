<?php

require_once('header.php');

$country = $_GET['country']



?>

<div class="m-5">



    <h1 class="text-primary mb-5"><span class="pb-1 px-2 border-bottom rounded-3  border-4 border-primary">Add University</span> </h1>

    <div class="container">
        <form method="post" id="frmdata" class="php-email-form" action="university-save" enctype="multipart/form-data">
            <div class="row">
                <div class="form-group fs-5 col-md-6">
                    <label for="university">University</label>
                    <input type="text" name="university" class="form-control form-control-lg" id="university">
                    <input type="hidden" name="username" class="form-control form-control-lg" id="username" value="<?php echo $name ?>">
                    <input type="hidden" name="userid" class="form-control form-control-lg" id="userid" value="<?php echo $id ?>">
                </div>

                <div class="form-group  fs-5 col-md-6">
                    <label for="url">Url</label>
                    <input type="text" name="url" class="form-control form-control-lg" id="url">
                </div>




                <div class="form-group  fs-5 col-md-6">
                    <label for="title">Title</label>
                    <input type="text" name="title" class="form-control form-control-lg" id="title">
                </div>

                <div class="form-group  fs-5 col-md-6">
                    <label for="keyword">Keyword</label>
                    <input type="text" name="keyword" class="form-control form-control-lg" id="keyword">
                </div>
                <div class="form-group  fs-5 col-md-6">
                    <label for="description">Description</label>
                    <input type="text" name="description" class="form-control form-control-lg" id="description">
                </div>

                <div class="form-group  fs-5 col-md-6">
                    <label for="country">Country</label>
                    <input type="text" name="country" class="form-control form-control-lg" id="country" value="<?php echo $country ?>" readonly>
                </div>

                <div class="form-group  fs-5 col-md-6">
                    <label for="state">State</label>

                    <select class="form-control form-control-lg" name="state" id="state">
                        <option value="">Select State</option>

                        <?php

                        $sql1 = "SELECT `state` FROM `state` WHERE `country`='$country' ORDER BY `state`";
                        $result1 = mysqli_query($conn, $sql1);
                        if (mysqli_num_rows($result1) > 0) {
                            while ($row1 = mysqli_fetch_assoc($result1)) {
                                echo '<option value="' . $row1['state'] . '">' . $row1['state'] . '</option>';
                            }
                        }
                        ?>
                    </select>
                </div>


                <div class="form-group col-md-12  fs-5">
                    <script src="ckeditor/ckeditor.js"></script>
                    <label for="editor">About University</label>
                    <textarea class="form-control" name="editor" id="editor" rows="15"></textarea>

                </div>


                <div class="form-group  fs-5 col-md-12">
                    <label for="card1head">Card 1 Heading</label>
                    <input type="text" name="card1head" class="form-control form-control-lg" id="card1head">
                </div>

                <div class="form-group col-md-12  fs-5">

                    <label for="card1con">Card 1 Content</label>
                    <textarea class="form-control" name="card1con" id="card1con" rows="6"></textarea>

                </div>


                <div class="form-group  fs-5 col-md-12">
                    <label for="card2head">Card 2 Heading</label>
                    <input type="text" name="card2head" class="form-control form-control-lg" id="card2head">
                </div>

                <div class="form-group col-md-12  fs-5">

                    <label for="card2con">Card 2 Content</label>
                    <textarea class="form-control" name="card2con" id="card2con" rows="6"></textarea>

                </div>


                <div class="form-group  fs-5 col-md-12">
                    <label for="card3head">Card 3 Heading</label>
                    <input type="text" name="card3head" class="form-control form-control-lg" id="card3head">
                </div>

                <div class="form-group col-md-12  fs-5">

                    <label for="card3con">Card 3 Content</label>
                    <textarea class="form-control" name="card3con" id="card3con" rows="6"></textarea>

                </div>


                <div class="form-group col-md-12  fs-5">

                    <label for="editor1">Course Fee</label>
                    <textarea class="form-control" name="editor1" id="editor1" rows="15"></textarea>

                </div>


                <div class="form-group col-md-12  fs-5">

                    <label for="editor2">University Fact</label>
                    <textarea class="form-control" name="editor2" id="editor2" rows="15"></textarea>

                </div>

                <div class="form-group col-md-12  fs-5">

                    <label for="editor3">Admission Proccess</label>
                    <textarea class="form-control" name="editor3" id="editor3" rows="15"></textarea>

                </div>


                <div class="text-center"><button type="Submit" class="fs-5 btn btn-outline-primary" id="adduniversity" name="adduniversity" value="Add University">Add University</button></div>


            </div>
        </form>
    </div>



    <script>

jQuery('#university').change(function(){
  
    var university = jQuery('#university').val();
var country = jQuery('#country').val();
// alert(course_type);
jQuery.ajax({
    url:'university-save',
    type:'POST',
    data:{
        university:university,
        country:country,
    },
    success:function(result){
       jQuery('#url').val(result);
    }
})

});

</script>


    <script>
        CKEDITOR.replace('editor');
    </script>

    <script>
        CKEDITOR.replace('editor1');
    </script>

    <script>
        CKEDITOR.replace('editor2');
    </script>

    <script>
        CKEDITOR.replace('editor3');
    </script>





    <?php

    require_once('footer.php');

    ?>