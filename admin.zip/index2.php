<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<!DOCTYPE html>
<html>

<head>
    <title>Dream Medicine</title>
    <link rel="stylesheet" href="login.css">
    <link href="assets/img/favicon.png" rel="icon">
</head>

<style>
    * {
        margin: 0px;
        padding: 0px;
        font-family: sans-serif;
    }

    body {
        background-image: url(https://pbs.twimg.com/media/EIi9qy0UcAAhyYl?format=jpg&name=large);
        background-repeat: no-repeat;
    }

    .login-page {
        height: 380px;
        width: 300px;
        background: rgba(0 0 0 .8);
        box-shadow: lightblue 0px 6px 10px 5px;
        margin: auto;
        margin-top: 150px;
        border-radius: 5px;
        margin-bottom: 50px;
    }

    .image-conteiner {
        height: 80px;
    }

    .image {
        height: 110px;
        width: 110px;
        background: #b5e6ef;
        border-radius: 50%;
        transform: translate(95px, -50px);
        padding: 5px;
    }

    .image img {
        height: 100px;
        width: 100px;
        border-radius: 50%;
    }

    .title {
        height: 30px;
        text-align: center;
    }

    .input-value {
        padding-top: 30px;
        height: 270px;
    }

    .input {
        padding-left: 25px;
    }

    .input input {
        border: none;
        border-bottom: 1px solid black;
        height: 30px;
        width: 250px;
    }

    #userid {
        padding-left: 5px;
        background: none;
    }

    #pass {
        padding-left: 5px;
        background: none;
    }

    #submit {
        display: inline-block;
        font-size: 20px;
        width: 140px;
        height: 40px;
        border: none;
        margin-left: 55px;
        background: #dd133b;
        border-radius: 20px;
        color: white;
    }

    input:focus-visible {
        outline-offset: 0px;
        outline-color: transparent;
        outline: #b5e6ef;

    }

    #submit:hover {
        background: none;
        border: 2px solid #dd133b;
        color: #dd133b;
        border-style: double;
        border-radius: 20px;
        transition: 0.5s;
    }

    .new {
        margin-left: 75px;
        margin-top: 10px;
    }

    .new a {
        text-decoration: none;
        color: black;
    }
</style>

<body>
    <div class="login-page">
        <div class="image-conteiner">
            <div class="image">
                <img src="assets/img/dream-old.png">
            </div>
        </div>
        <div class="title">
            <h3><span style="color:#eb0606;">Super</span><span style="color:#004aad;">Admin</span></h3>
        </div>
        <div class="input-value">
            <form action="login.php" method="POST">

                <div class="input">
                    <label>User Name</label><br>
                    <input type="text" name="email" id="userid" placeholder="user name" /><br><br>
                    <label>Password</label><br>
                    <input type="password" name="password" id="pass" placeholder="password" /><br><br>
                    <input type="submit" value="Sign In" name="btnsubmit" id="submit" />
                </div>

            </form>


        </div>
    </div>
</body>

</html>