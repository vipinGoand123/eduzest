<?php

// $host = "localhost";
// $user = "u533085254_green_tokari";
// $pass = "Vipin@123";
// $db = "u533085254_green_tokari";


$host = "localhost";
$user = "root";
$pass = "";
$db = "eduzest_nwa";

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
