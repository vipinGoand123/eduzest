<?php

require_once('config.php');

if(isset($_POST['adduniversityfaq'])){

    $university_name = $_POST['university_name'];
    $q1 = $_POST['q1'];
    $a1 = $_POST['a1'];
    $q2 = $_POST['q2'];
    $a2 = $_POST['a2'];
    $q3 = $_POST['q3'];
    $a3 = $_POST['a3'];
    $q4 = $_POST['q4'];
    $a4 = $_POST['a4'];
    $q5 = $_POST['q5'];
    $a5 = $_POST['a5'];
    $username = $_POST['username'];
    $userid = $_POST['userid'];

    $query = "INSERT INTO `university_faq`(`university_name`, `q1`, `a1`, `q2`, `a2`, `q3`, `a3`, `q4`, `a4`, `q5`, `a5`, `a_name`, `a_user_id`, `created_at`) VALUES ('$university_name','$q1','$a1','$q2','$a2','$q3','$a3','$q4','$a4','$q5','$a5','$username','$userid',NOW())";
      $result =  mysqli_query($conn, $query);

    if ($result) {

        $activity_name = "Add University Faq";
        $activity_desc = ' University Faq Added By ' . $username.' in '.$university_name;

        $query1 = "INSERT INTO `activity`(`user_id`,`activity_name`,`activity_desc`,`activity_time`) VALUE('$userid','$activity_name','$activity_desc', NOW())";
        mysqli_query($conn, $query1);

        echo '<script type="text/javascript">';
        echo 'alert("Added successfully");';
        echo 'window.location.href = "university-faq?university=' . $university_name. '";';
        echo '</script>';
    } else {
        echo '<script type="text/javascript">';
        echo 'alert("Failed to Add");';
        echo 'window.location.href = "add-university?university=' . $university_name . '";';

        echo '</script>';
    }

}

if (isset($_POST['deleteid'])) {

    $deleteid = $_POST['deleteid'];
    $university = $_POST['university'];
    $username = $_POST['user_name'];
    $userid = $_POST['user_id'];

    $deletequery = "DELETE FROM `university_faq` WHERE `s_no`='$deleteid'";
    $result = mysqli_query($conn, $deletequery);
    if ($result == true) {

        $activity_name = "Delete University Faq";
        $activity_desc = ' University Faq Deleted By ' . $username.' From '.$university;

        $query2 = "INSERT INTO `activity`(`user_id`,`activity_name`,`activity_desc`,`activity_time`) VALUE('$userid','$activity_name','$activity_desc', NOW())";
        mysqli_query($conn, $query2);

        echo 'Detele';
    } else {
        echo 'Failed';
    }
}




if(isset($_POST['updateuniversityfaq'])){

    $s_no = $_POST['university_name'];
    $university_name = $_POST['university_name'];
    $q1 = $_POST['q1'];
    $a1 = $_POST['a1'];
    $q2 = $_POST['q2'];
    $a2 = $_POST['a2'];
    $q3 = $_POST['q3'];
    $a3 = $_POST['a3'];
    $q4 = $_POST['q4'];
    $a4 = $_POST['a4'];
    $q5 = $_POST['q5'];
    $a5 = $_POST['a5'];
    $username = $_POST['username'];
    $userid = $_POST['userid'];

    $query = "UPDATE `university_faq` SET `university_name`='$university_name',`q1`='$q1',`a1`='$a1',`q2`='$q2',`a2`='$a2',`q3`='$q3',`a3`='$a3',`q4`='$q4',`a4`='$a4',`q5`='$q5',`a5`='$a5',`u_name`='$username',`u_user_id`='$userid',`last_update_time`=Now() WHERE `s_no`='$s_no'";
      $result =  mysqli_query($conn, $query);

    if ($result) {

        $activity_name = "Update University Faq";
        $activity_desc = ' University Faq Updated By ' . $username.' in '.$university_name;

        $query1 = "INSERT INTO `activity`(`user_id`,`activity_name`,`activity_desc`,`activity_time`) VALUE('$userid','$activity_name','$activity_desc', NOW())";
        mysqli_query($conn, $query1);

        echo '<script type="text/javascript">';
        echo 'alert("Updated successfully");';
        echo 'window.location.href = "university-faq?university=' . $university_name. '";';
        echo '</script>';
    } else {
        echo '<script type="text/javascript">';
        echo 'alert("Failed to Update");';
        echo 'window.location.href = "add-university?university=' . $university_name . '";';

        echo '</script>';
    }

}



?>