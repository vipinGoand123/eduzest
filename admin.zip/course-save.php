<?php

if(isset($_POST['course']) && isset($_POST['course_type'])){
$count = $_POST['course'];
$ctype = $_POST['course_type'];

$count = strtolower($count);
$ctype = strtolower($ctype);

$count = str_replace([' ','$','&','@',',','*','.'], ['-','-','-','-','-','-',''], $count);
$ctype = str_replace([' ','$','&','@','.',',','*'], ['-','-','-','-','-','-',''], $ctype);
echo '/'.$ctype.'/'.$count;

}

require_once('config.php');

if (isset($_POST['addcourse'])) {

    $course = $_POST['course'];
    $course_url = $_POST['course_url'];
    $course_type = $_POST['course_type'];
    $duration = $_POST['duration'];
    $course_title = $_POST['course_title'];
    $keyword = $_POST['keyword'];
    $description = $_POST['description'];
    $alt = $_POST['alt'];
    $editor = $_POST['editor'];
    $username = $_POST['username'];
    $userid = $_POST['userid'];


    $query = "INSERT INTO `courses`(`course`, `course_url`, `course_type`, `duration`, `course_title`, `keyword`, `description`, `alt`, `editor`, `a_name`, `a_user_id`, `created_at`) VALUES ('$course','$course_url','$course_type','$duration','$course_title','$keyword','$description','$alt','$editor','$username','$userid',NOW())";

    $result = mysqli_query($conn, $query);

    if ($result) {

        $activity_name = "Add Course";
        $activity_desc = $course . ' Course Added By ' . $username;

        $query1 = "INSERT INTO `activity`(`user_id`,`activity_name`,`activity_desc`,`activity_time`) VALUE('$userid','$activity_name','$activity_desc', NOW())";
        mysqli_query($conn, $query1);

        echo '<script type="text/javascript">';
        echo 'alert("Added successfully");';
        echo 'window.location.href = "courses";';
        echo '</script>';
    } else {
        echo '<script type="text/javascript">';
        echo 'alert("Failed to Add");';
        echo 'window.location.href = "add-courses";';

        echo '</script>';
    }
}


if (isset($_POST['deleteid'])) {

    $deleteid = $_POST['deleteid'];
    $coursename = $_POST['coursename'];
    $user_name = $_POST['user_name'];
    $user_id = $_POST['user_id'];

    $deletequery = "DELETE FROM `courses` WHERE `s_no`='$deleteid'";
    $result = mysqli_query($conn, $deletequery);
    if ($result == true) {

        $activity_name = "Delete Course";
        $activity_desc = $coursename . ' Course Deleted By ' . $user_name;

        $query1 = "INSERT INTO `activity`(`user_id`,`activity_name`,`activity_desc`,`activity_time`) VALUE('$user_id','$activity_name','$activity_desc', NOW())";
        mysqli_query($conn, $query1);

        echo 'Detele';
    } else {
        echo 'Failed';
    }
}



if (isset($_POST['updatecourse'])) {

    $s_no = $_POST['s_no'];
    $course = $_POST['course'];
    $course_url = $_POST['course_url'];
    $course_type = $_POST['course_type'];
    $duration = $_POST['duration'];
    $course_title = $_POST['course_title'];
    $keyword = $_POST['keyword'];
    $description = $_POST['description'];
    $alt = $_POST['alt'];
    $editor = $_POST['editor'];
    $username = $_POST['username'];
    $userid = $_POST['userid'];

    $updatequery = "UPDATE `courses` SET `course`='$course',`course_url`='$course_url',`course_type`='$course_type',`duration`='$duration',`course_title`='$course_title',`keyword`='$keyword',`description`='$description',`alt`='$alt',`editor`='$editor',`u_name`='$username',`u_user_id`='$userid',`last_update_time`=NOW()  WHERE `s_no`='$s_no'";

    $result = mysqli_query($conn, $updatequery);
    if ($result) {

        $activity_name = "Update Course";
        $activity_desc = $course . ' Course Updated By ' . $username;

        $query1 = "INSERT INTO `activity`(`user_id`,`activity_name`,`activity_desc`,`activity_time`) VALUE('$userid','$activity_name','$activity_desc', NOW())";
        mysqli_query($conn, $query1);

        echo '<script>
              alert("Updated Successfully")
              window.location.href = "course-details?course=' . $course_type . '";
             </script>';
    } else {
        echo '<script>
              alert("Updated Failed")
              window.location.href = "update-courses";
             </script>';
    }
}
