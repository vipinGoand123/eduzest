<?php

require_once('header.php');
require_once('config.php');

$university = $_GET['university'];

$sql3 = "SELECT s_no FROM `university_faq` WHERE `university_name`='$university'";
$result3 = $conn->query($sql3);
if(mysqli_num_rows($result3)>0){
while ($rows3 = $result3->fetch_assoc()) {

    $s_no = $rows3['s_no'];

}}

?>


<div class="midde_cont">
    <div class="container-fluid">
        <div class="row column_title">
            <div class="col-md-12">
                <div class="page_title">
                    <h2>University FAQ Details</h2>
                </div>
            </div>
        </div>
       

        <div class="row column1">
            <div class="col-md-12">
                <div class="full margin_bottom_30" style="background: #f8f8f8; min-height:56vh;">
                    <div class="full row graph_head">
                        <div class="heading col-6 margin_0 m-a">
                            <h2><?php echo $university ?> University FAQ</h2>
                        </div>
                        <div class="heading col-6 text-right margin_0">
                            <a href="add-university-faq?university=<?php echo $university ?>" class="btn btn-outline-primary fs-5">+ FAQ</a>

                            <input type="hidden" name="user_name" id="user_name" value="<?php echo $name ?>">
                            <button onclick="EditUser(<?php echo $s_no ?>)" type="submit" name="s_no" id="s_no" value="<?php echo $s_no ?>" class="btn btn-outline-warning fs-5">Update</button>
                            <input type="hidden" name="university" id="university" value="<?php echo $university ?>">
                            <button onclick="DeleteUser(<?php echo $s_no ?>)" class="btn btn-outline-danger fs-5">Delete</button>
                        </div>
                        
                        <hr class="my-3">

                        <div class="my-2">
                            <form action="" method="post" id="frmdata" class="php-email-form d-flex flex-column" enctype="multipart/form-data">
                                <table class="table table-bordered table-striped fs-5">

                               
                                    <tr>
                                        <th>No.</th>
                                        <th>Question</th>
                                        <th>Answer</th>
                                    </tr>



                                    <?php

                                    $sql = " SELECT * FROM `university_faq` WHERE `university_name`='$university'";
                                    $result = $conn->query($sql);
                                    if(mysqli_num_rows($result)>0){
                                    while ($rows = $result->fetch_assoc()) {
                                    ?>

                                        <tr>
                                            <td>1</td>
                                            <td><?php echo $rows['q1'] ?></td>
                                            <td><?php echo $rows['a1'] ?></td>
                                        </tr>

                                        <tr>
                                            <td>2</td>
                                            <td><?php echo $rows['q2'] ?></td>
                                            <td><?php echo $rows['a2'] ?></td>
                                        </tr>

                                        <tr>
                                            <td>3</td>
                                            <td><?php echo $rows['q3'] ?></td>
                                            <td><?php echo $rows['a3'] ?></td>
                                        </tr>

                                        <tr>
                                            <td>4</td>
                                            <td><?php echo $rows['q4'] ?></td>
                                            <td><?php echo $rows['a4'] ?></td>
                                        </tr>

                                        <tr>
                                            <td>5</td>
                                            <td><?php echo $rows['q5'] ?></td>
                                            <td><?php echo $rows['a5'] ?></td>
                                        </tr>

                                    <?php
                                       
                                    }
                                }
                                    ?>
                                </table>
                            </form>

                        </div>


                    </div>
                </div>
            </div>
        </div>

    </div>
</div>




<script>
    function EditUser(id) {

        $.ajax({
            url: 'update-university-faq',
            type: 'POST',
            data: {
                id: id,
            },
            success: function(response) {
                // Handle the response data here
                console.log(response);
                // Redirect to the desired page
                window.location.href = 'update-university-faq';
            },
            error: function(xhr, status, error) {
                console.error(error);
            }
        });
    }
</script>



<script>
    // Delete Function

    function DeleteUser(deleteid) {

        var university = $('#university').val();
        var user_name = $('#user_name').val();
        var user_id = $('#user_id').val();

        var conf = confirm("Are you sure");
        if (conf == true) {
            $.ajax({
                url: 'university-faq-save',
                type: 'POST',
                data: {
                    deleteid: deleteid,
                    university: university,
                    user_name: user_name,
                    user_id: user_id,
                },
                success: function(data, status) {

                    // alert(data);
                    window.location.reload();

                }
            });
        }
    }
</script>


<?php

require_once('footer.php');

?>