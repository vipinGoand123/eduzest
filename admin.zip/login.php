<?php
session_start();
include_once('config.php');


$_SESSION['sess_id'] = date('ymdhis');
$sessid = $_SESSION['sess_id'];

if (isset($_POST['btnsubmit'])) {

    $username = $_POST['email'];
    $password = $_POST['password'];
    $sql = "SELECT `s_no`, `email`, `password`, `created_at` FROM `admin` WHERE `email`='$username' AND `password`='$password'";
    $result = mysqli_query($conn, $sql);
    if ($result->num_rows >= 1) {
        $_SESSION['user'] = $username;


        while ($row = mysqli_fetch_assoc($result)) {

            $s_no = $row['s_no'];
            $activity_name = "Login";
            $activity_desc = "Login User";

            $query = "INSERT INTO `activity`(`user_id`,`activity_name`,`activity_desc`,`login_time`,`session_id`) VALUE('$s_no','$activity_name','$activity_desc',NOW(),'$sessid') ";
            $res = mysqli_query($conn, $query);
            if ($res) {
                echo "<script>location.href='dashboard';</script>";
            }
        }
    } else {
        echo "<script>alert('User name or password is wrong');</script>";
        //echo $sql;
        echo "<script>location.href='index';</script>";
    }
}
