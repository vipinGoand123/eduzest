<?php
require_once('config.php');
session_start();
if (isset($_SESSION['user'])) {
    $id =  $_SESSION['user'];
    $query = "SELECT * FROM `admin` WHERE `email` = '$id'";
    $result = $conn->query($query);
    while ($rows = $result->fetch_assoc()) {

        $name = $rows['name'];
        $id = $rows['s_no'];
    }
} else {
    echo "<script>location.href='index';</script>";
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <!-- basic -->
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <!-- mobile metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="viewport" content="initial-scale=1, maximum-scale=1" />
    <!-- site metas -->
    <title>EduZest</title>
    <meta name="keywords" content="" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <!-- site icon -->
    <link rel="icon" href="images/fevicon.png" type="image/png" />
    <!-- bootstrap css -->
    <link rel="stylesheet" href="css/bootstrap.min.css" />
    <link rel="stylesheet" href="css/bootstrap.css" />
    <!-- site css -->
    <link rel="stylesheet" href="style.css" />
    <!-- responsive css -->
    <link rel="stylesheet" href="css/responsive.css" />
    <!-- color css -->
    <!-- <link rel="stylesheet" href="css/color_2.css" /> -->
    <!-- select bootstrap -->
    <link rel="stylesheet" href="css/bootstrap-select.css" />
    <!-- scrollbar css -->
    <link rel="stylesheet" href="css/perfect-scrollbar.css" />
    <!-- custom css -->
    <link rel="stylesheet" href="css/custom.css" />

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.0/jquery.min.js" integrity="sha512-3gJwYpMe3QewGELv8k/BX9vcqhryRdzRMxVfq6ngyWXwo03GFEzjsUm8Q7RZcHPHksttq7/GFoxjCVUjkjvPdw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>


    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.4/dist/jquery.slim.min.js"></script>

    <script src="https://code.jquery.com/jquery-3.7.0.js" integrity="sha256-JlqSTELeR4TLqP0OG9dxM7yDPqX1ox/HfgiSLBj8+kM=" crossorigin="anonymous"></script>

    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

    <script src="https://kit.fontawesome.com/715001f945.js" crossorigin="anonymous"></script>


    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous"></script>

</head>

<body class="dashboard dashboard_1">
    <div class="full_container">
        <div class="inner_container">
            <!-- Sidebar  -->
            <nav id="sidebar">
                <div class="sidebar_blog_1">
                    <div class="sidebar-header">
                        <div class="logo_section">
                            <a href="dashboard"><img class="logo_icon img-responsive" src="images/logo/logo1.png" alt="#" /></a>
                        </div>
                    </div>
                    <div class="sidebar_user_info">
                        <div class="icon_setting"></div>
                        <div class="user_profle_side">
                            <div class="user_img">
                                <img class="img-responsive" src="images/layout_img/dummy-profile.png" alt="#" />
                            </div>
                            <div class="user_info">
                                <h6><?php echo $name ?></h6>
                                <p><span class="online_animation"></span> Online</p>
                            </div>
                        </div>
                    </div>
                </div>
                <input type="hidden" id="user_name" name="user_name" value="<?php echo $name ?>">
                <input type="hidden" id="user_id" name="user_id" value="<?php echo $id ?>">
                <div class="sidebar_blog_2">
                    <h4>General</h4>
                    <ul class="list-unstyled components">
                        <li class="active">
                            <a href="dashboard"><i class="fa fa-dashboard yellow_color"></i>
                                <span>Dashboard</span></a>

                        </li>
                        <li>
                            <a href="courses"><i class="fa-solid fa-book-open-reader text-primary"></i>
                                <span>Course Type</span></a>
                        </li>
                        <li>
                            <a href="region"><i class="fa-solid fa-city text-light"></i>
                                <span>Region</span></a>
                        </li>

                        <li>
                            <a href="university"><i class="fa-solid text-warning fa-graduation-cap"></i></i>
                                <span>University</span></a>
                        </li>

                        <li>
                            <a href="university-image"><i class="fa-solid text-warning fa-graduation-cap"></i></i>
                                <span>University Image</span></a>
                        </li>

                        <li>
                            <a href="contact-enquiry">
                                <i class="fa fa-paper-plane red_color"></i>
                                <span>Contact</span></a>
                        </li>
                        <li>
                            <a href="contact-page">
                                <i class="fa fa-paper-plane red_color"></i>
                                <span>Contact Page</span></a>
                        </li>
                        <li>
                            <a href="#element" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-diamond purple_color"></i>
                                <span>Elements</span></a>
                            <ul class="collapse list-unstyled" id="element">
                                <li>
                                    <a href="general_elements.html">> <span>General Elements</span></a>
                                </li>
                                <li>
                                    <a href="media_gallery.html">> <span>Media Gallery</span></a>
                                </li>
                                <li>
                                    <a href="icons.html">> <span>Icons</span></a>
                                </li>
                                <li>
                                    <a href="invoice.html">> <span>Invoice</span></a>
                                </li>
                            </ul>
                        </li>
                        <li>
                            <a href="tables.html"><i class="fa fa-table purple_color2"></i>
                                <span>Tables</span></a>
                        </li>
                        <li>
                            <a href="#apps" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-object-group blue2_color"></i>
                                <span>Apps</span></a>
                            <ul class="collapse list-unstyled" id="apps">
                                <li>
                                    <a href="email.html">> <span>Email</span></a>
                                </li>
                                <li>
                                    <a href="calendar.html">> <span>Calendar</span></a>
                                </li>
                                <li>
                                    <a href="media_gallery.html">> <span>Media Gallery</span></a>
                                </li>
                            </ul>
                        </li>
                        <li>
                            <a href="price.html"><i class="fa fa-briefcase blue1_color"></i>
                                <span>Pricing Tables</span></a>
                        </li>

                        <li class="active">
                            <a href="#additional_page" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-clone yellow_color"></i>
                                <span>Additional Pages</span></a>
                            <ul class="collapse list-unstyled" id="additional_page">
                                <li>
                                    <a href="profile.html">> <span>Profile</span></a>
                                </li>
                                <li>
                                    <a href="project.html">> <span>Projects</span></a>
                                </li>
                                <li>
                                    <a href="login.html">> <span>Login</span></a>
                                </li>
                                <li>
                                    <a href="404_error.html">> <span>404 Error</span></a>
                                </li>
                            </ul>
                        </li>
                        <li>
                            <a href="map.html"><i class="fa fa-map purple_color2"></i> <span>Map</span></a>
                        </li>
                        <li>
                            <a href="charts.html"><i class="fa fa-bar-chart-o green_color"></i>
                                <span>Charts</span></a>
                        </li>
                        <li>
                            <a href="settings.html"><i class="fa fa-cog yellow_color"></i>
                                <span>Settings</span></a>
                        </li>
                    </ul>
                </div>
            </nav>
            <!-- end sidebar -->

            <div id="content">
                <!-- topbar -->
                <div class="topbar">
                    <nav class="navbar navbar-expand-lg navbar-light">
                        <div class="full">
                            <button type="button" id="sidebarCollapse" class="sidebar_toggle">
                                <i class="fa fa-bars"></i>
                            </button>
                            <div class="logo_section">
                                <a href="dashboard"><img class="img-responsive" src="images/logo/logo1.png" alt="#" /></a>
                            </div>
                            <div class="right_topbar">
                                <div class="icon_info">
                                    <ul>
                                        <li>
                                            <a href="#"><i class="fa fa-bell-o"></i><span class="badge">2</span></a>
                                        </li>
                                        <li>
                                            <a href="#"><i class="fa fa-question-circle"></i></a>
                                        </li>
                                        <li>
                                            <a href="#"><i class="fa fa-envelope-o"></i><span class="badge">3</span></a>
                                        </li>
                                    </ul>
                                    <ul class="user_profile_dd">
                                        <li>
                                            <a class="dropdown-toggle" data-toggle="dropdown"><img class="img-responsive rounded-circle" src="images/layout_img/dummy-profile.png" alt="#" /><span class="name_user"><?php echo $name ?></span></a>
                                            <div class="dropdown-menu">
                                                <a class="dropdown-item" href="profile.html">My Profile</a>
                                                <a class="dropdown-item" href="settings.html">Settings</a>
                                                <a class="dropdown-item" href="help.html">Help</a>
                                                <a class="dropdown-item" href="#" name="btnlogout" id="btnlogout" value="Log out"><span>Log Out</span><i class="fa fa-sign-out"></i></a>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </nav>
                </div>
                <!-- end topbar -->


                <script>
                    $(document).ready(function(e) {
                        $('#btnlogout').on('click', function(e) {
                            var logout = 'logout';
                            // alert(logout);
                            $.ajax({
                                url: "logout",
                                method: "post",
                                data: {
                                    logout: logout
                                },
                                success: function(data) {
                                    // alert(data);
                                    location.href = 'index';

                                }

                            });
                        });
                    });
                </script>