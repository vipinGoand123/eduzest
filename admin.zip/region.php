<?php

require_once('header.php');
require_once('config.php');




?>

<div class="midde_cont">
    <div class="container-fluid">
        <div class="row column_title">
            <div class="col-md-12">
                <div class="page_title">
                    <h2>Region</h2>
                </div>
            </div>
        </div>

        <div class="row column1">
            <div class="col-md-12">
                <div class="full margin_bottom_30" style="background: #f8f8f8; min-height:56vh;">
                    <div class="full row graph_head">
                        <div class="heading col-6 margin_0 m-a">
                            <h2>Region</h2>
                        </div>



                        <hr class="my-3">

                        <div class="row column1">
                            <div class="col-md-6 col-lg-4">
                                <a href="region-details?region=Asia">
                                    <div class="full counter_section margin_bottom_30">
                                        <div class="couter_icon">
                                            <div>
                                                <i class="fa-solid fa-city text-primary"></i>
                                            </div>
                                        </div>
                                        <div class="counter_no">
                                            <div>
                                                <?php

                                                $sql = "SELECT * FROM `country` WHERE `region`='Asia'";

                                                if ($result = mysqli_query($conn, $sql)) {
                                                    $rowcount = mysqli_num_rows($result);
                                                    echo '<p class="total_no">' . $rowcount . '</p>';
                                                }

                                                ?>

                                                <p class="head_couter">Asia</p>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="col-md-6 col-lg-4">
                                <a href="region-details?region=East Europe">
                                    <div class="full counter_section margin_bottom_30">
                                        <div class="couter_icon">
                                            <div>
                                                <i class="fa-solid fa-city text-primary"></i>
                                            </div>
                                        </div>
                                        <div class="counter_no">
                                            <div>
                                                <?php

                                                $sql = "SELECT * FROM `country` WHERE `region`='East Europe'";

                                                if ($result = mysqli_query($conn, $sql)) {
                                                    $rowcount = mysqli_num_rows($result);
                                                    echo '<p class="total_no">' . $rowcount . '</p>';
                                                }

                                                ?>
                                                <p class="head_couter">East Europe</p>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="col-md-6 col-lg-4">
                                <a href="region-details?region=European Union">
                                    <div class="full counter_section margin_bottom_30">
                                        <div class="couter_icon">
                                            <div>
                                                <i class="fa-solid fa-city text-primary"></i>
                                            </div>
                                        </div>
                                        <div class="counter_no">
                                            <div>
                                                <?php

                                                $sql = "SELECT * FROM `country` WHERE `region`='European Union'";

                                                if ($result = mysqli_query($conn, $sql)) {
                                                    $rowcount = mysqli_num_rows($result);
                                                    echo '<p class="total_no">' . $rowcount . '</p>';
                                                }

                                                ?>
                                                <p class="head_couter">European Union</p>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>

                        </div>

                    </div>



                </div>
            </div>
            <!-- end row -->
        </div>

    </div>

</div>





<?php

require_once('footer.php')

?>