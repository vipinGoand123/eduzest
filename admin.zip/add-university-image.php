<?php

require_once('header.php');

$universityname = $_GET['universityname'];
$country = $_GET['country'];


?>

<div class="m-5">



    <h1 class="text-primary mb-5"><span class="pb-1 px-2 border-bottom rounded-3  border-4 border-primary">Add University Image</span> </h1>

    <div class="container">
        <form method="post" id="frmdata" class="php-email-form" action="university-image-save" enctype="multipart/form-data">
            <div class="row">
                <div class="form-group fs-5 col-md-12 mb-5">
                    <label for="university">University</label>
                    <input type="text" name="university" class="form-control form-control-lg" id="university" value="<?php echo $universityname ?>" readonly>
                    <input type="hidden" name="username" class="form-control form-control-lg" id="username" value="<?php echo $name ?>">
                    <input type="hidden" name="userid" class="form-control form-control-lg" id="userid" value="<?php echo $id ?>">
                    <input type="hidden" name="country" class="form-control form-control-lg" id="country" value="<?php echo $id ?>">
                </div>


                <div class="form-group  fs-5 col-md-6">
                    <label for="logo">University Logo</label>
                    <input type="file" name="logo" class="form-control form-control-lg" id="logo">
                </div>

                <div class="form-group  fs-5 col-md-6">
                    <label for="logoalt">University Logo Alt</label>
                    <input type="text" name="logoalt" class="form-control form-control-lg" id="logoalt">
                </div>

                <div class="form-group  fs-5 col-md-6">
                    <label for="thum">University Thum</label>
                    <input type="file" name="thum" class="form-control form-control-lg" id="thum">
                </div>

                <div class="form-group  fs-5 col-md-6">
                    <label for="thumalt">University Thum Alt</label>
                    <input type="text" name="thumalt" class="form-control form-control-lg" id="thumalt">
                </div>

                <div class="form-group  fs-5 col-md-6">
                    <label for="banner1">University Banner 1</label>
                    <input type="file" name="banner1" class="form-control form-control-lg" id="banner1">
                </div>

                <div class="form-group  fs-5 col-md-6">
                    <label for="banner1alt">University Banner 1 Alt</label>
                    <input type="text" name="banner1alt" class="form-control form-control-lg" id="banner1alt">
                </div>

                <div class="form-group  fs-5 col-md-6">
                    <label for="banner2">University Banner 2</label>
                    <input type="file" name="banner2" class="form-control form-control-lg" id="banner2">
                </div>

                <div class="form-group  fs-5 col-md-6">
                    <label for="banner2alt">University Banner 2 Alt</label>
                    <input type="text" name="banner2alt" class="form-control form-control-lg" id="banner2alt">
                </div>


                <div class="text-center"><button type="Submit" class="fs-5 btn btn-outline-primary" id="adduniversityimage" name="adduniversityimage" value="Add University Image">Add University Image</button></div>


            </div>
        </form>
    </div>


    <?php

    require_once('footer.php');

    ?>