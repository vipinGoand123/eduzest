<?php

require_once('header.php');
require_once('config.php');




?>

<div class="midde_cont">
    <div class="container-fluid">
        <div class="row column_title">
            <div class="col-md-12">
                <div class="page_title">
                    <h2>Course Type</h2>
                </div>
            </div>
        </div>

        <div class="row column1">
            <div class="col-md-12">
                <div class="full margin_bottom_30" style="background: #f8f8f8; min-height:56vh;">
                    <div class="full row graph_head">
                        <div class="heading col-6 margin_0 m-a">
                            <h2>Course Type</h2>
                        </div>

                        <div class="heading col-6 text-right margin_0">
                            <a href="add-course-type" class="btn btn-outline-primary fs-5">+ Course Type</a>
                        </div>

                        <hr class="my-3">

                        <div class="row column1">

                            <?php
                            $sql1 = "SELECT*FROM `course_type` ORDER BY `course_type`";
                            $result1 = mysqli_query($conn, $sql1);
                            if (mysqli_num_rows($result1) > 0) {
                                while ($row1 = mysqli_fetch_assoc($result1)) {

                                    $course_type = $row1['course_type'];


                            ?>

                                    <div class="col-md-6 col-lg-4">

                                        <div class="full counter_section margin_bottom_30 d-block">
                                            <a class="d-flex w-100" href="course-details?course=<?php echo $row1['url'] ?>">
                                                <div class="couter_icon">
                                                    <div>
                                                        <i class="fa-solid fa-book-open-reader text-primary"></i>
                                                    </div>
                                                </div>
                                                <div class="counter_no">
                                                    <div>
                                                        <?php

                                                        $sql = "SELECT * FROM `courses` WHERE `course_type`='$course_type'";

                                                        if ($result = mysqli_query($conn, $sql)) {
                                                            $rowcount = mysqli_num_rows($result);
                                                            echo '<p class="total_no fw-bold">' . $rowcount . '</p>';
                                                        }

                                                        ?>

                                                        <p class="head_couter text-dark"><?php echo $row1['course_type'] ?></p>
                                                        <input type="hidden" id="course_type" name="course_type" value="<?php echo $row1['course_type'] ?>">
                                                    </div>
                                                </div>
                                            </a>
                                            <div class=" float-right d-flex mt-4 ">
                                                <div class="left_rating ">
                                                    <button type="button" onclick="DeleteUser(<?php echo $row1['s_no'] ?>)" class="btn  btn-xs">
                                                        <i class="fa-solid fs-4 text-danger fa-trash"></i>
                                                    </button>
                                                </div>
                                                <div class="right_button ">

                                                    <button type="button" onclick="EditUser(<?php echo $row1['s_no'] ?>)" class="btn  btn-xs">
                                                        <i class="fa-solid text-success fa-pen-to-square fs-4"></i> </i>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>




                                    </div>
                            <?php
                                }
                            }
                            ?>


                        </div>

                    </div>



                </div>
            </div>
            <!-- end row -->
        </div>

    </div>

</div>

<script>
    function EditUser(id) {

        $.ajax({
            url: 'update-course-type',
            type: 'POST',
            data: {
                id: id,
            },
            success: function(response) {
                // Handle the response data here
                console.log(response);
                // Redirect to the desired page
                window.location.href = 'update-course-type';
            },
            error: function(xhr, status, error) {
                console.error(error);
            }
        });
    }
</script>



<script>
    // Delete Function

    function DeleteUser(deleteid) {

        var course_type = $('#course_type').val();
        var user_name = $('#user_name').val();
        var user_id = $('#user_id').val();

        var conf = confirm("Are you sure");
        if (conf == true) {
            $.ajax({
                url: 'course-type-save',
                type: 'POST',
                data: {
                    deleteid: deleteid,
                    course_type: course_type,
                    user_name: user_name,
                    user_id: user_id,
                },
                success: function(data, status) {

                    // alert(data);
                    window.location.reload();

                }
            });
        }
    }
</script>





<?php

require_once('footer.php')

?>