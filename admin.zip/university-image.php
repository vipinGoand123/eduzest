<?php

require_once('header.php');
require_once('config.php');



?>




<div class="midde_cont">
    <div class="container-fluid">
        <div class="row column_title">
            <div class="col-md-12">
                <div class="page_title">
                    <h2>Country</h2>
                </div>
            </div>
        </div>

        <div class="row column1">
            <div class="col-md-12">
                <div class="full margin_bottom_30" style="background: #f8f8f8; min-height:56vh;">
                    <div class="full row graph_head">
                        <div class="heading col-6 margin_0 m-a">
                            <h2>Country</h2>
                        </div>


                        <hr class="my-3">

                        <div class="row column1">

                            <?php

                            $sql = " SELECT * FROM `country` Order by 	
`s_no` DESC ";
                            $result = $conn->query($sql);

                            while ($rows = $result->fetch_assoc()) {
                                $rows['country']
                            ?>

                                <div class="col-md-6 col-lg-4 pb-4">
                                    <a href="university-image-details?country=<?php echo $rows['country'] ?>">
                                        <div class="contact_blog">
                                            <h4 class="brief"><?php echo $rows['region'] ?></h4>
                                            <div class="contact_inner">
                                                <div class="left">
                                                    <h3><?php echo $rows['country'] ?></h3>
                                                    <input type="hidden" id="country_name" name="country_name" value="<?php echo $rows['country'] ?>">




                                                    <ul class="list-unstyled">
                                                        <li>

                                                            <?php
                                                            $country = $rows['country'];

                                                            $sql2 = "SELECT `name` FROM `university` WHERE `country`='$country'";
                                                            $result2 = mysqli_query($conn, $sql2);

                                                            $rowcount2 = mysqli_num_rows($result2);


                                                            echo ' <p><strong>University: </strong>' . $rowcount2 . '</p>';
                                                            ?>


                                                        </li>

                                                    </ul>
                                                </div>
                                                <div class="right">
                                                    <div class="profile_contacts">
                                                        <img class="img-responsive" height="100" src="../assets/img/country-flag/<?php echo $rows['image'] ?>" alt="<?php echo $rows['alt'] ?>" />
                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                    </a>
                                </div>

                            <?php
                            } ?>




                        </div>

                    </div>



                </div>
            </div>
            <!-- end row -->
        </div>

    </div>

</div>



<script>
    function EditUser(id) {

        $.ajax({
            url: 'update-country',
            type: 'POST',
            data: {
                id: id,
            },
            success: function(response) {
                // Handle the response data here
                console.log(response);
                // Redirect to the desired page
                window.location.href = 'update-country';
            },
            error: function(xhr, status, error) {
                console.error(error);
            }
        });
    }
</script>



<script>
    // Delete Function

    function DeleteUser(deleteid) {

        var countryname = $('#country_name').val();
        var user_name = $('#user_name').val();
        var user_id = $('#user_id').val();

        var conf = confirm("Are you sure");
        if (conf == true) {
            $.ajax({
                url: 'country-save',
                type: 'POST',
                data: {
                    deleteid: deleteid,
                    coursename: countryname,
                    user_name: user_name,
                    user_id: user_id,
                },
                success: function(data, status) {

                    // alert(data);
                    window.location.reload();

                }
            });
        }
    }
</script>



<?php

require_once('footer.php')

?>