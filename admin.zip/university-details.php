<?php

require_once('header.php');
require_once('config.php');

$country = $_GET['country'];

?>


<div class="midde_cont">
    <div class="container-fluid">
        <div class="row column_title">
            <div class="col-md-12">
                <div class="page_title">
                    <h2>University Details</h2>
                </div>
            </div>
        </div>

        <div class="row column1">
            <div class="col-md-12">
                <div class="full margin_bottom_30" style="background: #f8f8f8; min-height:56vh;">
                    <div class="full row graph_head">
                        <div class="heading col-6 margin_0 m-a">
                            <h2><?php echo $country ?> University List</h2>
                        </div>
                        <div class="heading col-6 text-right margin_0">
                            <a href="add-university?country=<?php echo $country ?>" class="btn btn-outline-primary fs-5">+ University</a>
                        </div>
                        <hr class="my-3">

                        <div class="my-2">
                            <form action="" method="post" id="frmdata" class="php-email-form d-flex flex-column" enctype="multipart/form-data">
                                <table class="table table-bordered table-striped fs-5">
                                    <tr>
                                        <th>No.</th>
                                        <th>University Name</th>
                                        <th>URL</th>
                                        <th>Country</th>
                                        <th>Title</th>
                                        <th>FAQ</th>
                                        <th>Course</th>
                                        <th>Update</th>
                                        <th>Delete</th>

                                    </tr>



                                    <?php

                                    $sql = " SELECT * FROM `university` WHERE `country`='$country' Order by 	
                    `s_no` DESC ";
                                    $result = $conn->query($sql);
                                    $number = 1;
                                    while ($rows = $result->fetch_assoc()) {
                                    ?>

                                        <tr>
                                            <td><?php echo $number ?></td>
                                            <td><?php echo $rows['name'] ?></td>
                                            <input type="hidden" id="university" name="university" value="<?php echo $rows['name'] ?>">
                                            <td><?php echo $rows['url'] ?></td>
                                            <td><?php echo $rows['country'] ?></td>
                                            <td><?php echo $rows['title'] ?></td>

                                            <td><a class="btn btn-success " href="university-faq?university=<?php echo $rows['name'] ?>">Veiw</a></td>
                                            <td>
                                                <a class="btn btn-success " href="university-course?university=<?php echo $rows['name'] ?>">Veiw</a>
                                            </td>
                                            <td>

                                                <button onclick="EditUser(<?php echo $rows['s_no'] ?>)" type="submit" name="s_no" id="s_no" value="<?php echo $rows['s_no'] ?>" class="btn btn-warning ">Update</button>
                                            </td>
                                            <td><button onclick="DeleteUser(<?php echo $rows['s_no'] ?>)" class="btn btn-danger">Delete</button></td>

                                        </tr>

                                    <?php
                                        $number++;
                                    }

                                    ?>
                                </table>
                            </form>

                        </div>


                    </div>
                </div>
            </div>
        </div>

    </div>
</div>


<script>
    function EditUser(id) {

        $.ajax({
            url: 'update-university',
            type: 'POST',
            data: {
                id: id,
            },
            success: function(response) {
                // Handle the response data here
                console.log(response);
                // Redirect to the desired page
                window.location.href = 'update-university';
            },
            error: function(xhr, status, error) {
                console.error(error);
            }
        });
    }
</script>



<script>
    // Delete Function

    function DeleteUser(deleteid) {

        var university = $('#university').val();
        var user_name = $('#user_name').val();
        var user_id = $('#user_id').val();

        var conf = confirm("Are you sure");
        if (conf == true) {
            $.ajax({
                url: 'university-save',
                type: 'POST',
                data: {
                    deleteid: deleteid,
                    university: university,
                    user_name: user_name,
                    user_id: user_id,
                },
                success: function(data, status) {

                    // alert(data);
                    window.location.reload();

                }
            });
        }
    }
</script>


<?php

require_once('footer.php');

?>