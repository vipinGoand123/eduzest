<?php

require_once('header.php');
require_once('config.php');

$country = $_GET['country'];

?>


<div class="midde_cont">
    <div class="container-fluid">
        <div class="row column_title">
            <div class="col-md-12">
                <div class="page_title">
                    <h2><?php echo $country ?> Details</h2>
                </div>
            </div>
        </div>

        <div class="row column1">
            <div class="col-md-12">
                <div class="full margin_bottom_30" style="background: #f8f8f8; min-height:56vh;">
                    <div class="full row graph_head">
                        <div class="heading col-6 margin_0 m-a">
                            <h2><?php echo $country ?> State List</h2>
                        </div>
                        <div class="heading col-6 text-right margin_0">
                            <a href="add-state?country=<?php echo $country ?>" class="btn btn-outline-primary fs-5">+ State</a>
                        </div>
                        <hr class="my-3">

                        <div class="my-2">
                            <form action="" method="post" id="frmdata" class="php-email-form d-flex flex-column" enctype="multipart/form-data">
                                <table class="table table-bordered table-striped fs-5">
                                    <tr>
                                        <th>No.</th>
                                        <th>State</th>
                                        <th>Country</th>
                                        <th>URL</th>
                                        <th>Title</th>
                                        <th>Keyword</th>
                                        <th>Update</th>
                                        <th>Delete</th>

                                    </tr>



                                    <?php

                                    $sql = " SELECT * FROM `state` WHERE `country`='$country' Order by 	
                    `s_no` DESC ";
                                    $result = $conn->query($sql);
                                    $number = 1;
                                    while ($rows = $result->fetch_assoc()) {
                                    ?>

                                        <tr>
                                            <td><?php echo $number ?></td>
                                            <td><?php echo $rows['state'] ?></td>
                                            <input type="hidden" id="state" name="state" value="<?php echo $rows['state'] ?>">
                                            <td><?php echo $rows['country'] ?></td>
                                            <td>https://eduzest.in<?php echo $rows['url'] ?></td>
                                            <td><?php echo $rows['title'] ?></td>

                                            <td><?php echo $rows['keyword'] ?></td>
                                            <td>

                                                <button onclick="EditUser(<?php echo $rows['s_no'] ?>)" type="submit" name="s_no" id="s_no" value="<?php echo $rows['s_no'] ?>" class="btn btn-warning ">Update</button>
                                            </td>
                                            <td><button onclick="DeleteUser(<?php echo $rows['s_no'] ?>)" class="btn btn-danger">Delete</button></td>

                                        </tr>

                                    <?php
                                        $number++;
                                    }

                                    ?>
                                </table>
                            </form>

                        </div>


                    </div>
                </div>
            </div>
        </div>

    </div>
</div>


<script>
    function EditUser(id) {

        $.ajax({
            url: 'update-state',
            type: 'POST',
            data: {
                id: id,
            },
            success: function(response) {
                // Handle the response data here
                console.log(response);
                // Redirect to the desired page
                window.location.href = 'update-state';
            },
            error: function(xhr, status, error) {
                console.error(error);
            }
        });
    }
</script>



<script>
    // Delete Function

    function DeleteUser(deleteid) {

        var state = $('#state').val();
        var user_name = $('#user_name').val();
        var user_id = $('#user_id').val();

        var conf = confirm("Are you sure");
        if (conf == true) {
            $.ajax({
                url: 'state-save',
                type: 'POST',
                data: {
                    deleteid: deleteid,
                    state: state,
                    user_name: user_name,
                    user_id: user_id,
                },
                success: function(data, status) {

                    // alert(data);
                    window.location.reload();

                }
            });
        }
    }
</script>


<?php

require_once('footer.php');

?>