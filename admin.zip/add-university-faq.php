<?php

require_once('header.php');
require_once('config.php');

$university = $_GET['university'];


?>

<div class="m-5">



    <h1 class="text-primary mb-5"><span class="pb-1 px-2 border-bottom rounded-3  border-4 border-primary">Add University FAQ</span> </h1>

    <div class="container">
        <form method="post" id="frmdata" class="php-email-form" action="university-faq-save" enctype="multipart/form-data">
            <div class="row">
                <div class="form-group fs-5 col-md-12">
                    <label for="university_name">University</label>
                    <input type="text" name="university_name" class="form-control form-control-lg" readonly id="university_name" value="<?php echo $university ?>">
                    <input type="hidden" name="username" class="form-control form-control-lg" id="username" value="<?php echo $name ?>">
                    <input type="hidden" name="userid" class="form-control form-control-lg" id="userid" value="<?php echo $id ?>">
                </div>

                

                <div class="form-group  fs-5 col-md-12">
                    <label for="q1">Question-1</label>
                    <input type="text" name="q1" class="form-control form-control-lg" id="q1">

                </div>

                <div class="form-group  fs-5 col-md-12">
                    <label for="a1">Answer-1</label>
                    <textarea class="form-control" name="a1" id="a1" rows="6"></textarea>
                </div>
                <div class="form-group  fs-5 col-md-12">
                    <label for="q2">Question-2</label>
                    <input type="text" name="q2" class="form-control form-control-lg" id="q2">
                </div>

                <div class="form-group  fs-5 col-md-12">
                    <label for="a2">Answer-2</label>
                    <textarea class="form-control" name="a2" id="a2" rows="6"></textarea>
                </div>
                <div class="form-group  fs-5 col-md-12">
                    <label for="q3">Question-3</label>
                    <input type="text" name="q3" class="form-control form-control-lg" id="q3">
                </div>


                <div class="form-group  fs-5 col-md-12">
                    <label for="a3">Answer-3</label>
                    <textarea class="form-control" name="a3" id="a3" rows="6"></textarea>
                </div>

                <div class="form-group  fs-5 col-md-12">
                    <label for="q4">Question-4</label>
                    <input type="text" name="q4" class="form-control form-control-lg" id="q4">
                </div>

                <div class="form-group col-md-12  fs-12">
                    
                    <label for="a4">Answer-4</label>
                    <textarea class="form-control" name="a4" id="a4" rows="6"></textarea>

                </div>


                <div class="form-group  fs-5 col-md-12">
                    <label for="q5">Question-5</label>
                    <input type="text" name="q5" class="form-control form-control-lg" id="q5">
                </div>

                <div class="form-group col-md-12  fs-12">
                    
                    <label for="a5">Answer-5</label>
                    <textarea class="form-control" name="a5" id="a5" rows="6"></textarea>

                </div>


                <div class="text-center"><button type="Submit" class="fs-5 btn btn-outline-primary" id="adduniversityfaq" name="adduniversityfaq" value="Add University FAQ">Add University FAQ</button></div>


            </div>
        </form>
    </div>



    <?php

    require_once('footer.php');

    ?>