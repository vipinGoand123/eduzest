<?php

require_once('header.php');
require_once('config.php');


?>

<?php

if (!empty($_POST['id'])) {
    $getid = $_POST['id'];
    $_SESSION['getid'] = $getid;
}
?>


<div class="m-5">



    <h1 class="text-primary mb-5"><span class="pb-1 px-2 border-bottom rounded-3  border-4 border-primary">Update Course Type</span> </h1>

    <div class="container">

        <?php

        $coursetypeid = $_SESSION['getid'];

        $sql = "SELECT * FROM `course_type` WHERE `s_no`='$coursetypeid'";
        $result = mysqli_query($conn, $sql);
        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {

                // echo $row['s_no'];

        ?>



                <form method="post" id="frmdata" class="php-email-form" action="course-type-save" enctype="multipart/form-data">
                    <div class="row">
                        <div class="form-group fs-5 col-md-6">
                            <label for="course_type">Course Type</label>
                            <input type="text" name="course_type" class="form-control form-control-lg" id="course_type" value="<?php echo $row['course_type'] ?>">
                            <input type="hidden" name="s_no" class="form-control form-control-lg" id="s_no" value="<?php echo $row['s_no'] ?>">
                            <input type="hidden" name="username" class="form-control form-control-lg" id="username" value="<?php echo $name ?>">
                            <input type="hidden" name="userid" class="form-control form-control-lg" id="userid" value="<?php echo $id ?>">
                        </div>

                        <div class="form-group  fs-5 col-md-6">
                            <label for="url">Url</label>
                            <input type="text" name="url" class="form-control form-control-lg" id="url" value="<?php echo $row['url'] ?>">
                        </div>

                        <div class="form-group  fs-5 col-md-6">
                            <label for="title">Title</label>
                            <input type="text" name="title" class="form-control form-control-lg" id="title" value="<?php echo $row['title'] ?>">
                        </div>

                        <div class="form-group  fs-5 col-md-6">
                            <label for="keyword">Keyword</label>
                            <input type="text" name="keyword" class="form-control form-control-lg" id="keyword" value="<?php echo $row['keyword'] ?>">
                        </div>
                        <div class="form-group  fs-5 col-md-6">
                            <label for="description">Description</label>
                            <input type="text" name="description" class="form-control form-control-lg" id="description" value="<?php echo $row['description'] ?>">
                        </div>




                        <div class="form-group col-md-12  fs-5">
                            <script src="ckeditor/ckeditor.js"></script>
                            <label for="editor">About Course Type</label>
                            <textarea class="form-control" name="editor" id="editor" rows="15"><?php echo $row['editor'] ?></textarea>

                        </div>


                        <div class="text-center"><button type="Submit" class="fs-5 btn btn-outline-primary" id="updatecoursetype" name="updatecoursetype" value="Update Course Type">Update Course</button></div>


                    </div>
                </form>

        <?php
            }
        }
        ?>
    </div>



    <script>
        CKEDITOR.replace('editor');
    </script>

    <?php

    require_once('footer.php');

    ?>