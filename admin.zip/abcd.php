<?php
require_once('header.php');
require_once('config.php');


$region = isset($_GET['country']) ? $_GET['country'] : '';

// Function to get the number of states for a country
function getNumberOfStates($country, $conn)
{
    $stmt = $conn->prepare("SELECT COUNT(*) as count FROM `state` WHERE `country` = ?");
    $stmt->bind_param("s", $country);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    return $row['count'];
}

?>

<!DOCTYPE html>
<html>

<head>
    <!-- Add your header content here -->
</head>

<body>

    <div class="midde_cont">
        <div class="container-fluid">
            <div class="row column_title">
                <div class="col-md-12">
                    <div class="page_title">
                        <h2>Country</h2>
                    </div>
                </div>
            </div>

            <div class="row column1">
                <div class="col-md-12">
                    <div class="full margin_bottom_30" style="background: #f8f8f8; min-height:56vh;">
                        <div class="full row graph_head">
                            <div class="heading col-6 margin_0 m-a">
                                <h2>Country</h2>
                            </div>

                            <div class="heading col-6 text-right margin_0">
                                <form action="add-state" method="post">
                                    <button type="submit" name="region" id="region" value="<?php echo htmlspecialchars($region); ?>" class="btn btn-outline-primary fs-5">+ State</button>
                                </form>
                            </div>

                            <hr class="my-3">

                            <div class="row column1">

                                <?php

                                $sql = "SELECT * FROM `country` WHERE `region` = ? ORDER BY `s_no` DESC";
                                $stmt = $conn->prepare($sql);
                                $stmt->bind_param("s", $region);
                                $stmt->execute();
                                $result = $stmt->get_result();

                                while ($rows = $result->fetch_assoc()) {
                                ?>

                                    <div class="col-md-6 col-lg-4">
                                        <a href="country-details?country=Asia">
                                            <div class="contact_blog">
                                                <h4 class="brief"><?php echo htmlspecialchars($rows['region']); ?></h4>
                                                <div class="contact_inner">
                                                    <div class="left">
                                                        <h3><?php echo htmlspecialchars($rows['country']); ?></h3>
                                                        <input type="hidden" id="country_name" name="country_name" value="<?php echo htmlspecialchars($rows['country']); ?>">

                                                        <?php
                                                        $country = $rows['country'];
                                                        echo htmlspecialchars($country);

                                                        $numOfStates = getNumberOfStates($country, $conn);
                                                        echo '<p><strong>State: </strong>' . htmlspecialchars($numOfStates) . '</p>';

                                                        ?>

                                                        <ul class="list-unstyled">
                                                            <li>
                                                                URL: <?php echo htmlspecialchars($rows['url']); ?>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                    <div class="right">
                                                        <div class="profile_contacts">
                                                            <img class="img-responsive" height="100" src="../assets/img/country-flag/<?php echo htmlspecialchars($rows['image']); ?>" alt="<?php echo htmlspecialchars($rows['alt']); ?>" />
                                                        </div>
                                                    </div>
                                                    <div class="bottom_list">
                                                        <div class="left_rating">
                                                            <button type="button" onclick="DeleteUser(<?php echo $rows['s_no']; ?>)" class="btn btn-danger btn-xs">
                                                                <i class="fa-solid fa-trash"></i> Delete
                                                            </button>
                                                        </div>
                                                        <div class="right_button">
                                                            <button type="button" onclick="EditUser(<?php echo $rows['s_no']; ?>)" class="btn btn-primary btn-xs">
                                                                <i class="fa-solid fa-pen-to-square"></i> Edit
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </a>
                                    </div>

                                <?php
                                } ?>

                            </div>

                        </div>
                    </div>
                </div>
                <!-- end row -->
            </div>
        </div>
    </div>

    <!-- Add your footer content here -->
    <?php
    require_once('footer.php');
    ?>

    <script>
        function EditUser(id) {
            $.ajax({
                url: 'update-country',
                type: 'POST',
                data: {
                    id: id,
                },
                success: function(response) {
                    // Handle the response data here
                    console.log(response);
                    // Redirect to the desired page
                    window.location.href = 'update-country';
                },
                error: function(xhr, status, error) {
                    console.error(error);
                }
            });
        }

        // Delete Function
        function DeleteUser(deleteid) {
            var countryname = $('#country_name').val();
            var user_name = $('#user_name').val();
            var user_id = $('#user_id').val();
            var conf = confirm("Are you sure");
            if (conf == true) {
                $.ajax({
                    url: 'country-save',
                    type: 'POST',
                    data: {
                        deleteid: deleteid,
                        coursename: countryname,
                        user_name: user_name,
                        user_id: user_id,
                    },
                    success: function(data, status) {
                        // alert(data);
                        window.location.reload();
                    },
                    error: function(xhr, status, error) {
                        console.error(error);
                    }
                });
            }
        }
    </script>

</body>

</html>