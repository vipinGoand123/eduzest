<?php


$count = $_POST['country'];
$stt = $_POST['state'];

$count = strtolower($count);
$stt = strtolower($stt);
$count = str_replace([' ','$','&','@','.',',','*'], ['-','-','-','-','-','-',''], $count);
$stt = str_replace([' ','$','&','@','.',',','*'], ['-','-','-','-','-','-',''], $stt);
echo '/'.$count.'/'.$stt;


require_once('config.php');

if (isset($_POST['addstate'])) {


    $state = $_POST['state'];
    $url = $_POST['url'];
    $country = $_POST['country'];
    $title = $_POST['title'];
    $keyword = $_POST['keyword'];
    $description = $_POST['description'];
    $editor = $_POST['editor'];
    $username = $_POST['username'];
    $userid = $_POST['userid'];

    $query = "INSERT INTO `state`(`country`, `state`, `keyword`, `description`, `title`, `url`, `editor`,`a_name`, `a_user_id`, `created_at`) VALUES ('$country','$state','$keyword','$description','$title','$url','$editor','$username','$userid',NOW())";

    $result = mysqli_query($conn, $query);

    if ($result) {

        $activity_name = "Add State";
        $activity_desc = $state . ' State Added By ' . $username;

        $query1 = "INSERT INTO `activity`(`user_id`,`activity_name`,`activity_desc`,`activity_time`) VALUE('$userid','$activity_name','$activity_desc', NOW())";
        mysqli_query($conn, $query1);

        echo '<script type="text/javascript">';
        echo 'alert("Added successfully");';
        echo 'window.location.href = "country-details?country=' . $country . '";';
        echo '</script>';
    } else {
        echo '<script type="text/javascript">';
        echo 'alert("Failed to Add");';
        echo 'window.location.href = "add-state?country=' . $country . '";';

        echo '</script>';
    }
}


if (isset($_POST['deleteid'])) {

    $deleteid = $_POST['deleteid'];
    $state = $_POST['state'];
    $user_name = $_POST['user_name'];
    $user_id = $_POST['user_id'];

    $deletequery = "DELETE FROM `state` WHERE `s_no`='$deleteid'";
    $result = mysqli_query($conn, $deletequery);
    if ($result == true) {

        $activity_name = "Delete State";
        $activity_desc = $state . ' State Deleted By ' . $user_name;

        $query1 = "INSERT INTO `activity`(`user_id`,`activity_name`,`activity_desc`,`activity_time`) VALUE('$user_id','$activity_name','$activity_desc', NOW())";
        mysqli_query($conn, $query1);

        echo 'Detele';
    } else {
        echo 'Failed';
    }
}



if (isset($_POST['updatestate'])) {

    $s_no = $_POST['s_no'];
    $state = $_POST['state'];
    $url = $_POST['url'];
    $country = $_POST['country'];
    $title = $_POST['title'];
    $keyword = $_POST['keyword'];
    $description = $_POST['description'];
    $editor = $_POST['editor'];
    $username = $_POST['username'];
    $userid = $_POST['userid'];


    $updatequery = "UPDATE `state` SET `state`='$state',`url`='$url',`url`='$url',`country`='$country',`title`='$title',`keyword`='$keyword',`description`='$description',`editor`='$editor',`u_name`='$username',`u_user_id`='$userid',`last_update_time`=NOW()  WHERE `s_no`='$s_no'";

    $result = mysqli_query($conn, $updatequery);
    if ($result) {

        $activity_name = "Update State";
        $activity_desc = $state . ' State Updated By ' . $username;

        $query1 = "INSERT INTO `activity`(`user_id`,`activity_name`,`activity_desc`,`activity_time`) VALUE('$userid','$activity_name','$activity_desc', NOW())";
        mysqli_query($conn, $query1);

        echo '<script>
              alert("Updated Successfully")
              window.location.href = "country-details?country=' . $country . '";
             </script>';
    } else {
        echo '<script>
              alert("Updated Failed")
              window.location.href = "update-country";
             </script>';
    }
}
