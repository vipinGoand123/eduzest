<?php

require_once('header.php')

?>

<div class="midde_cont">
    <div class="container-fluid">
        <div class="row column_title">
            <div class="col-md-12">
                <div class="page_title">
                    <h2>Contacts</h2>
                </div>
            </div>
        </div>

        <div id="addkdsb">

        </div>

        <div class="row column1">
            <div class="col-md-12">
                <div class="white_shd full margin_bottom_30">
                    <div class="full row graph_head">
                        <div class="heading col-6 margin_0 m-a">
                            <h2>Contacts</h2>
                        </div>
                        <div class="heading col-6 text-right margin_0">
                            <button type="button" class="btn btn-outline-primary fs-5" data-bs-toggle="modal" data-bs-target="#exampleModal">+ Contact Details</button>
                        </div>



                        <!-- Modal-start -->

                        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header" style="border:none">
                                        <h2 class="modal-title">Add Details</h2>

                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>

                                    <form class="p-4">
                                        <div class="mb-3">
                                            <label for="email" class="form-label fs-4">Email address</label>
                                            <input type="email" class="form-control fs-4" id="email" name="email" aria-describedby="emailHelp">
                                            <div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div>
                                        </div>
                                        <div class="mb-3">
                                            <label for="number" class="form-label fs-4">Number</label>
                                            <input type="text" class="form-control fs-4" id="number" name="number">
                                        </div>
                                        <div class="mb-3">
                                            <label for="city" class="form-label fs-4">City</label>
                                            <input type="text" class="form-control fs-4" id="city" name="city">
                                        </div>
                                        <div class="mb-3">
                                            <label for="address" class="form-label fs-4">Address</label>
                                            <input type="text" class="form-control fs-4" id="address" name="address">
                                        </div>
                                        <div class="mb-3 form-check">
                                            <input type="checkbox" class="form-check-input fs-5" id="exampleCheck1" checked>
                                            <label class="form-check-label fs-5" for="exampleCheck1">Check me out</label>
                                        </div>



                                        <div class="modal-footer" style="border:none">
                                            <!-- <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button> -->
                                            <button type="button" onclick="addRecord()" class="btn btn-primary" data-bs-dismiss="modal">Submit</button>
                                        </div>

                                    </form>
                                </div>
                            </div>
                        </div>


                        <!-- update -->

                        <div class="modal fade" id="update_user_model" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header" style="border:none;">

                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>

                                    <form class="p-3">
                                        <div class="mb-3">
                                            <label for="u_email" class="form-label fs-4">Email address</label>
                                            <input type="email" class="form-control fs-4" id="u_email" name="u_email" aria-describedby="emailHelp">
                                            <div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div>
                                        </div>
                                        <div class="mb-3">
                                            <label for="u_number" class="form-label fs-4">Number</label>
                                            <input type="text" class="form-control fs-4" id="u_number" name="u_number">
                                        </div>
                                        <div class="mb-3">
                                            <label for="u_city" class="form-label fs-4">City</label>
                                            <input type="text" class="form-control fs-4" id="u_city" name="u_city">
                                        </div>
                                        <div class="mb-3">
                                            <label for="u_address fs-4" class="form-label">Address</label>
                                            <input type="text" class="form-control fs-4" id="u_address" name="u_address">
                                        </div>
                                        <div class="mb-3 form-check">
                                            <input type="checkbox" class="form-check-input" id="exampleCheck1">
                                            <label class="form-check-label" for="exampleCheck1">Check me out</label>
                                        </div>

                                        <input type="hidden" name="" id="hidden_user_id">

                                        <div class="modal-footer" style="border:none;">
                                            <!-- <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button> -->
                                            <button type="button" onclick="updateRecord()" class="btn btn-primary" data-bs-dismiss="modal">Update</button>
                                        </div>

                                    </form>
                                </div>
                            </div>
                        </div>

                        <!-- End Update -->


                        <!-- Modal-End -->

                    </div>


                    <!-- <div class="full price_table padding_infor_info">
                        <div class="row">

                            <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12 profile_details margin_bottom_30">
                                <div class="contact_blog">
                                    <h4 class="brief">Digital Strategist</h4>
                                    <div class="contact_inner">
                                        <div class="left">
                                            <h3>John Smith</h3>
                                            <p>
                                                <strong>About: </strong>Frontend Developer
                                            </p>
                                            <ul class="list-unstyled">
                                                <li>
                                                    <i class="fa fa-envelope-o"></i> :
                                                    test@gmail.com
                                                </li>
                                                <li>
                                                    <i class="fa fa-phone"></i> : 987 654 3210
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="right">
                                            <div class="profile_contacts">
                                                <img class="img-responsive" src="images/layout_img/msg2.png" alt="#" />
                                            </div>
                                        </div>
                                        <div class="bottom_list">
                                            <div class="left_rating">
                                                <button type="button" class="btn btn-danger btn-xs">
                                                    <i class="fa-solid fa-trash"></i> Delete
                                                </button>
                                            </div>
                                            <div class="right_button">

                                                <button type="button" class="btn btn-primary btn-xs">
                                                    <i class="fa-solid fa-pen-to-square"></i> </i>Edit
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            

                        </div>
                    </div> -->



                    <div class="full price_table padding_infor_info">
                        <div class="row" id="records_contant">
                            <!-- column contact -->


                            <!-- end column contact blog -->

                        </div>
                    </div>
                </div>
            </div>
            <!-- end row -->
        </div>

    </div>

</div>



<script>
    $(document).ready(function() {
        readRecords()
    })

    function readRecords() {
        var readRecord = "readRecord";

        $.ajax({
            url: 'contact-page-save.php',
            type: "POST",
            data: {
                readRecord: readRecord
            },
            success: function(data, status) {
                $('#records_contant').html(data);
            }
        });
    }

    function addRecord() {
        var email = $('#email').val();
        var number = $('#number').val();
        var city = $('#city').val();
        var address = $('#address').val();

        $.ajax({
            url: 'contact-page-save.php',
            type: 'POST',
            data: {
                email: email,
                number: number,
                city: city,
                address: address,

            },
            // beforeSend: function() {
            //     alert("hi");
            // },
            success: function(data) {
                $('#addkdsb').html(data);
                readRecords(data);
            }
        });
    }


    // Delete Function

    function DeleteUser(deleteid) {
        var conf = confirm("Are you sure");
        if (conf == true) {
            $.ajax({
                url: 'contact-page-save.php',
                type: 'POST',
                data: {
                    deleteid: deleteid
                },
                success: function(data, status) {
                    $('#addkdsb').html(data);
                    readRecords();
                }
            });
        }
    }


    function EditUser(id) {
        $('#hidden_user_id').val(id);
        $.post("contact-page-save.php", {
                id: id
            },
            function(data, status) {
                var user = JSON.parse(data);
                $('#u_email').val(user.email);
                $('#u_number').val(user.phone);
                $('#u_city').val(user.city);
                $('#u_address').val(user.address);
            }
        );
        $('#update_user_model').modal("show");
    }


    function updateRecord() {
        var email_u = $('#u_email').val();
        var number_u = $('#u_number').val();
        var city_u = $('#u_city').val();
        var address_u = $('#u_address').val();

        var hidden_user_id_u = $('#hidden_user_id').val();


        $.post("contact-page-save.php", {
                hidden_user_id_u: hidden_user_id_u,
                email_u: email_u,
                number_u: number_u,
                city_u: city_u,
                address_u: address_u,
            },


            function(data) {
                $('#update_user_model').modal("hide");
                $('#addkdsb').html(data);
                readRecords();
            }
        );
    }
</script>






<?php

require_once('footer.php')

?>