<?php

require_once('config.php');

if (isset($_POST['adduniversityimage'])) {


    $username = $_POST['username'];
    $userid = $_POST['userid'];
    $university = $_POST['university'];
    $logoalt = $_POST['logoalt'];
    $thumalt = $_POST['thumalt'];
    $banner1alt = $_POST['banner1alt'];
    $banner2alt = $_POST['banner2alt'];
    $country = $_POST['country'];



    $file  = $_FILES['logo'];
    $filename = $file['name'];
    $filepath = $file['tmp_name'];
    $fileeror = $file['error'];

    $destfile = '../assets/img/university/logo/' . $filename;

    move_uploaded_file($filepath, $destfile);


    $file  = $_FILES['thum'];
    $filename1 = $file['name'];
    $filepath = $file['tmp_name'];
    $fileeror = $file['error'];

    $destfile = '../assets/img/university/thum/' . $filename1;

    move_uploaded_file($filepath, $destfile);


    $file  = $_FILES['banner1'];
    $filename2 = $file['name'];
    $filepath = $file['tmp_name'];
    $fileeror = $file['error'];

    $destfile = '../assets/img/university/banner/' . $filename2;

    move_uploaded_file($filepath, $destfile);


    $file  = $_FILES['banner2'];
    $filename3 = $file['name'];
    $filepath = $file['tmp_name'];
    $fileeror = $file['error'];

    $destfile = '../assets/img/university/banner/' . $filename3;

    move_uploaded_file($filepath, $destfile);




    $query = "INSERT INTO `university_image`(`university_name`,`country`, `logo`, `banner1`, `banner2`, `thum`, `logoalt`, `thumalt`, `banner1alt`, `banner2alt`, `a_name`, `a_user_id`, `created_at`) VALUES ('$university','$country','$filename','$filename2','$filename3','$filename1','$logoalt','$thumalt','$banner1alt','$banner2alt','$username','$userid',NOW())";

    $result = mysqli_query($conn, $query);

    if ($result) {

        $activity_name = "Add University Image";
        $activity_desc = $university . ' Image Added By ' . $username;

        $query1 = "INSERT INTO `activity`(`user_id`,`activity_name`,`activity_desc`,`activity_time`) VALUE('$userid','$activity_name','$activity_desc', NOW())";
        mysqli_query($conn, $query1);

        echo '<script type="text/javascript">';
        echo 'alert("Added successfully");';
        echo 'window.location.href = "university-image-details?country=' . $country . ';';
        echo '</script>';
    } else {
        echo '<script type="text/javascript">';
        echo 'alert("Failed to Add");';
        echo 'window.location.href = "add-country?region=' . $region . '";';

        echo '</script>';
    }
}


if (isset($_POST['deleteid'])) {

    $deleteid = $_POST['deleteid'];
    $countryname = $_POST['countryname'];
    $user_name = $_POST['user_name'];
    $user_id = $_POST['user_id'];

    $deletequery = "DELETE FROM `country` WHERE `s_no`='$deleteid'";
    $result = mysqli_query($conn, $deletequery);
    if ($result == true) {

        $activity_name = "Delete Country";
        $activity_desc = $countryname . ' Country Deleted By ' . $user_name;

        $query1 = "INSERT INTO `activity`(`user_id`,`activity_name`,`activity_desc`,`activity_time`) VALUE('$user_id','$activity_name','$activity_desc', NOW())";
        mysqli_query($conn, $query1);

        echo 'Detele';
    } else {
        echo 'Failed';
    }
}



if (isset($_POST['updatecountry'])) {

    $s_no = $_POST['s_no'];
    $country = $_POST['country'];
    $url = $_POST['url'];
    $region = $_POST['region'];
    $title = $_POST['title'];
    $keyword = $_POST['keyword'];
    $description = $_POST['description'];
    $editor = $_POST['editor'];
    $username = $_POST['username'];
    $userid = $_POST['userid'];
    $alt = $_POST['alt'];


    $file  = $_FILES['image'];
    $filename = $file['name'];
    $filepath = $file['tmp_name'];
    $fileeror = $file['error'];

    $destfile = '../assets/img/country-flag/' . $filename;

    move_uploaded_file($filepath, $destfile);


    $updatequery = "UPDATE `Country` SET `country`='$country',`url`='$url',`title`='$title',`keyword`='$keyword',`region`='$region',`description`='$description',`image`='$filename',`alt`='$alt',`editor`='$editor',`u_name`='$username',`u_user_id`='$userid',`last_update_time`=NOW()  WHERE `s_no`='$s_no'";

    $result = mysqli_query($conn, $updatequery);
    if ($result) {

        $activity_name = "Update Country";
        $activity_desc = $country . ' Country Updated By ' . $username;

        $query1 = "INSERT INTO `activity`(`user_id`,`activity_name`,`activity_desc`,`activity_time`) VALUE('$userid','$activity_name','$activity_desc', NOW())";
        mysqli_query($conn, $query1);

        echo '<script>
              alert("Updated Successfully")
              window.location.href = "region-details?region=' . $region . '";
             </script>';
    } else {
        echo '<script>
              alert("Updated Failed")
              window.location.href = "update-country";
             </script>';
    }
}
