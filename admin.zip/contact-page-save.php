<?php

require_once('config.php');

extract($_POST);

if (isset($_POST['readRecord'])) {


    $displayquery = "SELECT * FROM `contact_page` ORDER BY `s_no` DESC";
    $result = mysqli_query($conn, $displayquery);
    if (mysqli_num_rows($result) > 0) {

        while ($row = mysqli_fetch_array($result)) {

            $data = ' <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12 profile_details margin_bottom_30">
            <div class="contact_blog">
            
            <div class="contact_inner">
                <div class="kdsb">
                    <h3>' . $row['city'] . '</h3>
                    <p>
                        <strong>Office: </strong>' . $row['address'] . '
                    </p>
                    <ul class="list-unstyled">
                        <li>
                            <i class="fa fa-envelope-o"></i> :
                           ' . $row['email'] . '
                        </li>
                        <li>
                            <i class="fa fa-phone"></i> : ' . $row['phone'] . '
                        </li>
                    </ul>
                </div>

                <div class="bottom_list">
                    <div class="left_rating">
                        <button type="button" onclick="DeleteUser(' . $row['s_no'] . ')" class="btn btn-danger btn-xs">
                            <i class="fa-solid fa-trash"></i> Delete
                        </button>
                    </div>
                    <div class="right_button">

                        <button type="button" onclick="EditUser(' . $row['s_no'] . ')" class="btn btn-primary btn-xs">
                            <i class="fa-solid fa-pen-to-square"></i> </i>Edit
                        </button>
                    </div>
                </div>
            </div>
        </div>
        </div>';

            echo $data;
        }
    }
}


if (isset($_POST['email']) && isset($_POST['number']) && isset($_POST['city']) && isset($_POST['address'])) {

    $query = "INSERT INTO `contact_page`(`email`, `phone`, `city`, `address`, `created_at`) VALUES ('$email','$number', '$city','$address', NOW())";

    $result =  mysqli_query($conn, $query);
    if ($result == true) {
        echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Added Successfuly!</strong> You should check in on some of those fields below.
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>';
    } else {
        echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
        <strong>Failed to Add!</strong>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>';
    }
}


// delete

if (isset($_POST['deleteid'])) {
    $userid = $_POST['deleteid'];
    $deletequery = "DELETE FROM `contact_page` WHERE s_no='$userid'";
    $result = mysqli_query($conn, $deletequery);
    if ($result == true) {
        echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Deleted Successfuly!</strong> You should check in on some of those fields below.
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>';
    } else {
        echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
        <strong> Failed To Delete!</strong>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>';
    }
}


// Get Data


if (isset($_POST['id']) && isset($_POST['id']) != "") {
    $user_id = $_POST['id'];
    $query = "SELECT *FROM `contact_page` WHERE s_no='$user_id'";
    if (!$result = mysqli_query($conn, $query)) {
        // exit(mysqli_error());
    }
    $response = array();
    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_array($result)) {
            $response = $row;
        }
    } else {
        $response['status'] = 200;
        $response['message'] = "Data not found";
    }
    echo json_encode($response);
} else {
    $response['status'] = 200;
    $response['message'] = "Invalid ";
}


// update table

if (isset($_POST['hidden_user_id_u'])) {
    $hidden_user_id_u = $_POST['hidden_user_id_u'];
    $email_u = $_POST['email_u'];
    $number_u = $_POST['number_u'];
    $city_u = $_POST['city_u'];
    $address_u = $_POST['address_u'];

    $query = "UPDATE `contact_page` SET `email`='$email_u',`phone`='$number_u',`city`='$city_u', `address`='$address_u' WHERE s_no='$hidden_user_id_u'";

    $result =  mysqli_query($conn, $query);
    if ($result == true) {
        echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Updated Successfuly!</strong> You should check in on some of those fields below.
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>';
    } else {
        echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
        <strong>Failed to Update!</strong> You should check in on some of those fields below.
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>';
    }
}


?>


<?php

?>
