<?php

require_once('header.php');



if (!empty($_POST['id'])) {
    $getid = $_POST['id'];
    $_SESSION['getid'] = $getid;
}



?>

<div class="m-5">



    <h1 class="text-primary mb-5"><span class="pb-1 px-2 border-bottom rounded-3  border-4 border-primary">Add University</span> </h1>

    <div class="container">

        <?php

        $s_no = $_SESSION['getid'];

        $sql = "SELECT * FROM `university_course` WHERE `s_no`='$s_no'";
        $result = mysqli_query($conn, $sql);
        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                // $country = $row['country'];
        ?>

                <form method="post" id="frmdata" class="php-email-form" action="university-course-save" enctype="multipart/form-data">
                    <div class="row">
                        <div class="form-group fs-5 col-md-6">
                            <label for="university">University</label>
                            <input type="text" name="university" class="form-control form-control-lg" id="university" value="<?php echo $row['university_name'] ?>">
                            <input type="hidden" name="username" class="form-control form-control-lg" id="username" value="<?php echo $name ?>">
                            <input type="hidden" name="userid" class="form-control form-control-lg" id="userid" value="<?php echo $id ?>">
                            <input type="hidden" name="s_no" class="form-control form-control-lg" id="s_no" value="<?php echo $row['s_no'] ?>">
                        </div>

                        <div class="form-group  fs-5 col-md-6">
                            <label for="course_type">Course Type</label>
                            <select class="form-control form-control-lg" name="course_type" id="course_type">
                               <option value="<?php echo $row['course_type'] ?>"><?php echo $row['course_type'] ?></option>
                               <option value="">Select Course Type</option>
                        <?php
                            $sql = "SELECT `course_type` FROM `course_type` ORDER BY `course_type`";
                            $result = mysqli_query($conn,$sql);
                            if(mysqli_num_rows($result)>0){
                                while($rows = mysqli_fetch_assoc($result)){
                                    ?>
                                    <option value="<?php echo $rows['course_type'] ?>"><?php echo $rows['course_type'] ?></option>
                                    <?php
                                }
                            }
                        ?>
                    </select>
                        </div>

                        <div class="form-group  fs-5 col-md-6">
                            <label for="course">Course</label>
                            <input type="text" name="course" class="form-control form-control-lg" id="course" value="<?php echo $row['course'] ?>">
                        </div>

                        <div class="form-group  fs-5 col-md-6">
                            <label for="url">Url</label>
                            <input type="text" name="url" class="form-control form-control-lg" id="url" value="<?php echo $row['url'] ?>">
                        </div>




                        <div class=" form-group fs-5 col-md-6">
                            <label for="title">Title</label>
                            <input type="text" name="title" class="form-control form-control-lg" id="title" value="<?php echo $row['title'] ?>">
                        </div>

                        <div class=" form-group fs-5 col-md-6">
                            <label for="keyword">Keyword</label>
                            <input type="text" name="keyword" class="form-control form-control-lg" id="keyword" value="<?php echo $row['keyword'] ?>">
                        </div>
                        <div class="form-group  fs-5 col-md-6">
                            <label for="description">Description</label>
                            <input type="text" name="description" class="form-control form-control-lg" id="description" value="<?php echo $row['description'] ?>">
                        </div>

                        </div>


                        <div class="form-group col-md-12  fs-5">
                            <script src="ckeditor/ckeditor.js"></script>
                            <label for="about_course">About University</label>
                            <textarea class="form-control" name="about_course" id="about_course" rows="15"><?php echo $row['about_course'] ?></textarea>

                        </div>


                        <div class="form-group  fs-5 col-md-12">
                            <label for="card1head">Card 1 Heading</label>
                            <input type="text" name="card1head" class="form-control form-control-lg" id="card1head" value="<?php echo $row['card1head'] ?>">
                        </div>

                        <div class="form-group col-md-12  fs-5">

                            <label for="card1con">Card 1 Content</label>
                            <textarea class="form-control" name="card1con" id="card1con" rows="6"><?php echo $row['card1con'] ?></textarea>

                        </div>


                        <div class="form-group  fs-5 col-md-12">
                            <label for="card2head">Card 2 Heading</label>
                            <input type="text" name="card2head" class="form-control form-control-lg" id="card2head" value="<?php echo $row['card2head'] ?>">
                        </div>

                        <div class="form-group col-md-12  fs-5">

                            <label for="card2con">Card 2 Content</label>
                            <textarea class="form-control" name="card2con" id="card2con" rows="6"><?php echo $row['card2con'] ?></textarea>

                        </div>


                        <div class="form-group  fs-5 col-md-12">
                            <label for="card3head">Card 3 Heading</label>
                            <input type="text" name="card3head" class="form-control form-control-lg" id="card3head" value="<?php echo $row['card3head'] ?>">
                        </div>

                        <div class="form-group col-md-12  fs-5">

                            <label for="card3con">Card 3 Content</label>
                            <textarea class="form-control" name="card3con" id="card3con" rows="6"><?php echo $row['card3con'] ?></textarea>

                        </div>


                        <div class="form-group col-md-12  fs-5">

                            <label for="course_benefit">Course Benfit</label>
                            <textarea class="form-control" name="course_benefit" id="course_benefit" rows="15"><?php echo $row['course_benefit'] ?></textarea>

                        </div>


                        <div class="form-group col-md-12  fs-5">

                            <label for="who_can_apply">Who Can Apply</label>
                            <textarea class="form-control" name="who_can_apply" id="who_can_apply" rows="15"><?php echo $row['who_can_apply'] ?></textarea>

                        </div>

                        <div class="form-group col-md-12  fs-5">

                            <label for="syllabus">Syllabus</label>
                            <textarea class="form-control" name="syllabus" id="syllabus" rows="15"><?php echo $row['syllabus'] ?></textarea>

                        </div>

                        <div class="form-group col-md-12  fs-5">

                            <label for="job_role">Job Role</label>
                            <textarea class="form-control" name="job_role" id="job_role" rows="15"><?php echo $row['job_role'] ?></textarea>

                        </div>


                        <div class="text-center"><button type="Submit" class="fs-5 btn btn-outline-primary" id="updateuniversitycourse" name="updateuniversitycourse" value="Update University Course">Update University Course</button></div>


                    </div>
                </form>

        <?php
            }
        }
        ?>
    </div>



    <script>
        CKEDITOR.replace('about_course');
    </script>

    <script>
        CKEDITOR.replace('course_benefit');
    </script>

    <script>
        CKEDITOR.replace('syllabus');
    </script>

    <script>
        CKEDITOR.replace('who_can_apply');
    </script>

    <script>
        CKEDITOR.replace('job_role');
    </script>





    <?php

    require_once('footer.php');

    ?>