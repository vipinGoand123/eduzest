<?php

require_once('header.php');
require_once('config.php');

$url = $_GET['course'];

$sql1 = "SELECT `course_type` FROM `course_type` WHERE `url`='$url'";
$result = mysqli_query($conn, $sql1);
if (mysqli_num_rows($result) > 0) {
    while ($row1 = mysqli_fetch_assoc($result)) {
        $course_type = $row1['course_type'];
    }
}

?>


<div class="midde_cont">
    <div class="container-fluid">
        <div class="row column_title">
            <div class="col-md-12">
                <div class="page_title">
                    <h2>Course Details</h2>
                </div>

            </div>
        </div>

        <div class="row column1">
            <div class="col-md-12">
                <div class="full margin_bottom_30" style="background: #f8f8f8; min-height:56vh;">
                    <div class="full row graph_head">
                        <div class="heading col-6 margin_0 m-a">
                            <h2><?php echo $course_type ?> List</h2>
                        </div>
                        <div class="heading col-6 text-right margin_0">
                            <a href="add-courses?course-type=<?php echo $url ?>" class="btn btn-outline-primary fs-5">+ Course</a>
                        </div>
                        <hr class="my-3">

                        <div class="my-2">
                            <form action="" method="post" id="frmdata" class="php-email-form d-flex flex-column" enctype="multipart/form-data">
                                <table class="table table-bordered table-striped fs-5">
                                    <tr>
                                        <th>No.</th>
                                        <th>Course</th>
                                        <th>Course URL</th>
                                        <th>Course Type</th>
                                        <th>Duration</th>
                                        <th>Title</th>
                                        <th>Keyword</th>
                                        <th>Update</th>
                                        <th>Delete</th>

                                    </tr>



                                    <?php

                                    $sql = " SELECT * FROM `courses` WHERE `course_type`='$course_type' Order by 	
                    `s_no` DESC ";
                                    $result = $conn->query($sql);
                                    $number = 1;
                                    while ($rows = $result->fetch_assoc()) {
                                    ?>

                                        <tr>
                                            <td><?php echo $number ?></td>
                                            <td><?php echo $rows['course'] ?></td>
                                            <input type="hidden" id="course_name" name="course_name" value="<?php echo $rows['course'] ?>">
                                            <td><?php echo $rows['course_url'] ?></td>
                                            <td><?php echo $rows['course_type'] ?></td>
                                            <td><?php echo $rows['duration'] ?></td>
                                            <td><?php echo $rows['course_title'] ?></td>
                                            <td><?php echo $rows['keyword'] ?></td>
                                            <td>

                                                <button onclick="EditUser(<?php echo $rows['s_no'] ?>)" type="submit" name="s_no" id="s_no" value="<?php echo $rows['s_no'] ?>" class="btn btn-warning ">Update</button>
                                            </td>
                                            <td><button onclick="DeleteUser(<?php echo $rows['s_no'] ?>)" class="btn btn-danger">Delete</button></td>

                                        </tr>

                                    <?php
                                        $number++;
                                    }

                                    ?>
                                </table>
                            </form>

                        </div>


                    </div>
                </div>
            </div>
        </div>

    </div>
</div>


<script>
    function EditUser(id) {

        $.ajax({
            url: 'update-courses',
            type: 'POST',
            data: {
                id: id,
            },
            success: function(response) {
                // Handle the response data here
                console.log(response);
                // Redirect to the desired page
                window.location.href = 'update-courses';
            },
            error: function(xhr, status, error) {
                console.error(error);
            }
        });
    }
</script>



<script>
    // Delete Function

    function DeleteUser(deleteid) {

        var coursename = $('#course_name').val();
        var user_name = $('#user_name').val();
        var user_id = $('#user_id').val();

        var conf = confirm("Are you sure");
        if (conf == true) {
            $.ajax({
                url: 'course-save',
                type: 'POST',
                data: {
                    deleteid: deleteid,
                    coursename: coursename,
                    user_name: user_name,
                    user_id: user_id,
                },
                success: function(data, status) {

                    // alert(data);
                    window.location.reload();

                }
            });
        }
    }
</script>


<?php

require_once('footer.php');

?>