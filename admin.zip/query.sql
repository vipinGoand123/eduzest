-- SELECT university.*, university_image.*
-- FROM university
-- LEFT OUTER JOIN university_image ON university.country=university_image.country;


CREATE TABLE `eduzest_nwa`.`university_approve` (`s_no` INT(255) NOT NULL AUTO_INCREMENT , `university_name` VARCHAR(225) NULL , `approved_by` VARCHAR(225) NULL , `a_name` VARCHAR(225) NULL , `a_user_id` VARCHAR(225) NULL , `u_name` VARCHAR(225) NULL , `u_user_id` VARCHAR(225) NULL , `last_update_time` DATE NULL , `created_at` DATETIME NULL , PRIMARY KEY (`s_no`)) ENGINE = InnoDB;


CREATE TABLE `eduzest_nwa`.`university_emi_details` (`s_no` INT(255) NOT NULL AUTO_INCREMENT , `university_name` VARCHAR(255) NULL , `about` TEXT NULL , `content` LONGTEXT NULL , `a_name` VARCHAR(255) NULL , `a_user_id` VARCHAR(255) NULL , `u_name` VARCHAR(255) NULL , `u_user_id` VARCHAR(255) NULL , `last_update_time` DATETIME NULL , `created_at` DATETIME NULL , PRIMARY KEY (`s_no`)) ENGINE = InnoDB;

ALTER TABLE `university_approve` ADD UNIQUE(`university_name`);

ALTER TABLE `university_emi_details` ADD UNIQUE(`university_name`);



CREATE TABLE `eduzest_nwa`.`university_course` (`s_no` INT(255) NOT NULL AUTO_INCREMENT , `university_name` VARCHAR(255) NULL , `about_course` LONGTEXT NULL , `card1head` TEXT NULL , `card1con` TEXT NULL , `card2head` TEXT NULL , `card2con` TEXT NULL , `card3head` TEXT NULL , `card3con` TEXT NULL , `course_benefit` LONGTEXT NULL , `who_can_apply` LONGTEXT NULL , `syllabus` LONGTEXT NULL , `job_role` LONGTEXT NULL , `course_type` VARCHAR(255) NULL , `a_name` VARCHAR(255) NULL , `a_user_id` VARCHAR(255) NULL , `u_name` VARCHAR(255) NULL , `u_user_id` VARCHAR(255) NULL , `created_at` DATETIME NULL , `last_update_time` DATETIME NULL , PRIMARY KEY (`s_no`)) ENGINE = InnoDB;

ALTER TABLE `university_course` ADD `course_category` VARCHAR(255) NULL AFTER `job_role`;